


	[Load module]
	module load intel/19.0.3.199
	module load impi/2019.3.199

	[Data]
	Original 15 text files

	[OpenMP]
	cd _openmp
	make run

	[MPI]
	cd _mpi
	make run
